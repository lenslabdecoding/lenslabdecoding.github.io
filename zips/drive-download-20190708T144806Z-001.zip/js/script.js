function revealMessage(){
	document.getElementByID("hiddenMessage").style.display='block';
}